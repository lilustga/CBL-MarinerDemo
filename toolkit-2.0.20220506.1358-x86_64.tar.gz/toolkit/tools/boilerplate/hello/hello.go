// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.

package hello

// World is a sample public (starts with a capital letter, must be commented) function.
func World() string {
	return "Hello, world!"
}
