echo Enabling service for Azure Serial Console
systemctl enable serial-getty@ttyS0.service
