#!/bin/bash
# cleanup
rm -rf /boot/*
rm -rf /usr/src/
rm -rf /home/*
rm -rf /var/log/*
