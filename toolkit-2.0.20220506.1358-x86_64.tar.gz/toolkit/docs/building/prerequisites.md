
# Build Requirements

## CBL-Mariner

Build Requirements on CBL-Mariner listed [here](./prerequisites-mariner.md).


## Ubuntu

Build Requirements on Ubuntu listed [here](./prerequisites-ubuntu.md).
